
### 20230403

* 1 前后端开始放在一起　Vue2+Gin
* 2 后端golang解决跨域问题
* 3 使用vue解决bootstrap模态框
vuejsでbootstrap5のmodalを使う  <https://qiita.com/kesuzuki/items/f87060a052887c7fdf51>

# yarn install ==>  yarn serve



